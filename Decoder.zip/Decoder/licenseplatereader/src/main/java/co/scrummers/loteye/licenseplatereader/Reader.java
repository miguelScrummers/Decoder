package co.scrummers.loteye.licenseplatereader;

import co.scrummers.loteye.licenseplatereader.jni.DecoderWrapper;

public class Reader {

    public String read(String path){

        DecoderWrapper wrapper = new DecoderWrapper();
        return wrapper.decodeImage("");
    }
}
