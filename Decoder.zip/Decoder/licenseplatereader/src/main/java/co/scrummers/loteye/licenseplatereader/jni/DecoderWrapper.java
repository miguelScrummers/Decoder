package co.scrummers.loteye.licenseplatereader.jni;

public class DecoderWrapper {

    static {
        System.loadLibrary("decoder");
    }

    public native String decodeImage(String path);
}

